Como iniciarlo?

npm run dev y ir a http://localhost:3000/




puede que npm install si te lo acabas de clonar
